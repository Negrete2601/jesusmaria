    <div class="container" style="background:#FFFFFF;" id="contenido">
        <hr>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8 col-xs-12">
                <div class="thumbnail">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/QbGDoV_HoFY"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
   